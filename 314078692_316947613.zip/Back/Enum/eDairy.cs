﻿using Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Back.Enum
{
    public enum eDairy
    {
        None,
        Pasta,
        Pizza,
        Other
    }
}
